PROPOSTA:
Desenvolver um sistema simples de autenticação de usuário utilizando React Context API para gerenciar
o estado global de autenticação entre componentes. O sistema deve conter uma tela de login e uma
área protegida que só pode ser acessada por usuários autenticados.
OBJETIVOS:
• Compreender o funcionamento do React Context.
• Aplicar Provider e Consumer ou useContext para compartilhar dados entre componentes.
• Simular a autenticação sem necessidade de backend, apenas manipulando estados locais.